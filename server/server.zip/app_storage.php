<?php 

    include_once('classes/class.database.php');
   // if(isset($_POST['package'])){
        
       // $db_Connection = new dbConnection();
        //$db_Connection->link = $db_connection->connect();
            
            $link = new mysqli('localhost', 'root', '', 'kucherioz');
            
           // $package = $_POST['package'];
            $package = 'ajkhgf'; 
            $sql = "SELECT price FROM apps WHERE package = '$package'";
            $query = $link->query($sql);
while($row = $query->fetch_assoc()){
    $price = $row[0];
    break;
}



$sql = "SELECT * FROM apps WHERE package != '$package'";
            
            $query = $link->query($sql);
            while ($row = $query->fetch_assoc()) {
                $fact_price = $price * $row['priority'] / 10;
            $sanya .= $row['app_name'].'+-+'.$fact_price.'+-+'.$row['priority'].'+-+'.$row['image'].'||||';    
            }
$gavno = substr($sanya, 0, strlen($sanya)-4);
echo $gavno;            
            
            
            
            
        
        
  //  }





?>